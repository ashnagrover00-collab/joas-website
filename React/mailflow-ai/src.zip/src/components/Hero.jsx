import { useState } from "react";
import { ArrowRight } from "lucide-react";

export default function Hero() {
  const [open, setOpen] = useState(false);

  return (
    <>
      <section className="relative min-h-screen flex items-center overflow-hidden bg-[#050816]">

        {/* Background Glow */}

        <div className="absolute inset-0">

          <div className="absolute -top-64 -left-64 w-[700px] h-[700px] rounded-full bg-blue-600/20 blur-[180px]" />

          <div className="absolute -bottom-64 -right-64 w-[700px] h-[700px] rounded-full bg-cyan-500/20 blur-[200px]" />

        </div>

        <div className="relative z-10 max-w-7xl mx-auto px-8 grid lg:grid-cols-2 gap-20 items-center">

          {/* LEFT SIDE */}

          <div>

            <div className="inline-flex items-center px-5 py-2 rounded-full border border-cyan-500/20 bg-cyan-500/10 text-cyan-300 text-sm mb-8">

              Official Partner of Lulal AI

            </div>

            <h1 className="text-5xl lg:text-7xl font-bold leading-tight">

              Your

              <span className="block mt-2 bg-gradient-to-r from-cyan-300 via-blue-400 to-cyan-400 bg-clip-text text-transparent drop-shadow-[0_0_12px_rgba(34,211,238,0.6)]">

                Digital Workforce

              </span>

              <span className="block mt-2">

                Starts Here

              </span>

            </h1>

            <p className="mt-10 text-xl text-gray-300 leading-9 max-w-xl">

              Deploy AI assistants that answer questions, automate repetitive
              tasks, analyze documents, support your teams and integrate
              seamlessly into your business—giving you a reliable digital
              workforce that works 24/7.

            </p>

            <div className="flex gap-5 mt-12">

              <button
                onClick={() => setOpen(true)}
                className="px-8 py-4 rounded-full bg-gradient-to-r from-blue-600 to-cyan-400 text-white font-semibold transition hover:scale-105"
              >
                Book Consultation
              </button>

              <button className="px-8 py-4 rounded-full border border-white/20 hover:bg-white hover:text-black transition flex items-center gap-2">

                Explore

                <ArrowRight size={18} />

              </button>

            </div>

          </div>

          {/* RIGHT SIDE */}

          <div className="flex justify-center">

            <div className="relative w-[650px] h-[650px]">

              {/* Outer Ring */}

              <div className="absolute inset-0 rounded-full border border-blue-500/20 animate-spin"
                   style={{ animationDuration: "35s" }}>
              </div>

              {/* Second Ring */}

              <div
                className="absolute inset-10 rounded-full border border-cyan-400/30 animate-spin"
                style={{
                  animationDirection: "reverse",
                  animationDuration: "22s",
                }}
              >
              </div>

              {/* Glow */}

              <div className="absolute inset-16 rounded-full bg-gradient-to-br from-blue-600/20 to-cyan-400/20 blur-xl">
              </div>

              {/* Circle Panel */}

              <div className="absolute inset-20 rounded-full border border-cyan-400/40 bg-[#09111f]/90 backdrop-blur-xl shadow-[0_0_80px_rgba(34,211,238,.15)]">
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center px-14">

                  {/* First */}

                  <div>

                    <h2 className="text-3xl lg:text-4xl font-bold text-white">
                      Your Personal
                    </h2>

                    <h2 className="text-3xl lg:text-4xl font-bold mt-1 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                      AI Assistant
                    </h2>

                  </div>

                  <div className="w-40 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent my-6"></div>

                  {/* Second */}

                  <div>

                    <h2 className="text-3xl lg:text-4xl font-bold text-white">
                      Everything
                    </h2>

                    <h2 className="text-3xl lg:text-4xl font-bold mt-1 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                      You Need
                    </h2>

                  </div>

                  <div className="w-40 h-px bg-gradient-to-r from-transparent via-cyan-400 to-transparent my-6"></div>

                  {/* Third */}

                  <div>

                    <h2 className="text-3xl lg:text-4xl font-bold text-white">
                      One Click
                    </h2>

                    <h2 className="text-3xl lg:text-4xl font-bold mt-1 bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent">
                      Away
                    </h2>

                  </div>

                </div>

              </div>

              {/* Orbit Dot */}

              <div className="absolute top-6 left-1/2 -translate-x-1/2 w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_20px_#22d3ee]"></div>

              <div className="absolute bottom-10 left-16 w-4 h-4 rounded-full bg-blue-500 shadow-[0_0_20px_#3b82f6]"></div>

              <div className="absolute right-8 top-1/2 -translate-y-1/2 w-4 h-4 rounded-full bg-cyan-400 shadow-[0_0_20px_#22d3ee]"></div>

              <div className="absolute bottom-16 right-20 w-4 h-4 rounded-full bg-blue-500 shadow-[0_0_20px_#3b82f6]"></div>

            </div>

          </div>

        </div>

      </section>
      {/* CONTACT POPUP */}

      {open && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-6">

          <div className="relative w-full max-w-2xl rounded-[32px] border border-cyan-500/20 bg-[#0B1120] p-10 shadow-[0_0_60px_rgba(34,211,238,.15)]">

            <button
              onClick={() => setOpen(false)}
              className="absolute right-6 top-5 text-4xl text-gray-400 hover:text-white transition"
            >
              ×
            </button>

            <p className="uppercase tracking-[4px] text-cyan-400 text-sm mb-3">
              CONTACT US
            </p>

            <h2 className="text-5xl font-bold mb-4">
              Ready To Start?
            </h2>

            <p className="text-gray-400 leading-8 mb-10">
              Tell us about your business and we'll help you discover how AI
              can automate workflows, improve productivity and accelerate
              growth.
            </p>

            <form className="space-y-5">

              <input
                type="text"
                placeholder="Full Name"
                className="w-full rounded-xl bg-[#111827] border border-white/10 p-5 outline-none focus:border-cyan-400 transition"
              />

              <input
                type="email"
                placeholder="Business Email"
                className="w-full rounded-xl bg-[#111827] border border-white/10 p-5 outline-none focus:border-cyan-400 transition"
              />

              <input
                type="text"
                placeholder="Company Name"
                className="w-full rounded-xl bg-[#111827] border border-white/10 p-5 outline-none focus:border-cyan-400 transition"
              />

              <textarea
                rows={5}
                placeholder="Tell us about your project..."
                className="w-full rounded-xl bg-[#111827] border border-white/10 p-5 outline-none resize-none focus:border-cyan-400 transition"
              />

              <button
                type="submit"
                className="w-full rounded-xl py-5 bg-gradient-to-r from-blue-600 to-cyan-400 font-semibold text-lg hover:scale-[1.02] transition"
              >
                Request Consultation
              </button>

            </form>

          </div>

        </div>
      )}
          </>
  );
}