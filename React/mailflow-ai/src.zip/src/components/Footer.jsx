import { Mail, Globe } from "lucide-react";

export default function Footer() {
  return (
    <footer className="border-t border-white/10">
      <div className="max-w-7xl mx-auto px-8 py-20">
        <div className="grid lg:grid-cols-4 gap-12">

          <div>
            <h2 className="text-3xl font-bold">JOAS AI</h2>

            <p className="text-gray-400 mt-6 leading-8">
              Enterprise AI consulting,
              automation,
              deployment
              and implementation.
            </p>
          </div>

          <div>
            <h3 className="font-semibold mb-6">Company</h3>
            <ul className="space-y-4 text-gray-400">
              <li>About</li>
              <li>Solutions</li>
              <li>Industries</li>
              <li>Contact</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-6">Resources</h3>
            <ul className="space-y-4 text-gray-400">
              <li>AI Consulting</li>
              <li>Enterprise AI</li>
              <li>Knowledge AI</li>
              <li>Automation</li>
            </ul>
          </div>

          <div>
            <h3 className="font-semibold mb-6">Connect</h3>

            <div className="flex gap-5">
              <Mail />
              <Globe />
            </div>
          </div>

        </div>

        <div className="border-t border-white/10 mt-16 pt-8 flex justify-between flex-wrap gap-4 text-gray-500">
          <p>© 2026 JOAS AI. All Rights Reserved.</p>
          <p>Official Partner of Lulal AI</p>
        </div>
      </div>
    </footer>
  );
}