import { Menu } from "lucide-react";

export default function Navbar() {
    return (

        <header className="fixed top-0 left-0 w-full z-50">

            <nav className="mx-auto max-w-7xl h-20 px-8 flex items-center justify-between backdrop-blur-xl">

                <div className="flex items-center gap-3">

                    <img
  src="/Logo.PNG"
  alt="JOAS AI"
  className="h-13 w-13 object-cover rounded-2xl bg-white/5 p-1 border border-white/10 shadow-lg"
/>

                    <span className="font-bold text-2xl tracking-wide">
                        JOAS AI
                    </span>

                </div>

                <ul className="hidden lg:flex items-center gap-10">

                    <li>
                        <a
                            href="#"
                            className="hover:text-blue-400 transition"
                        >
                            Solutions
                        </a>
                    </li>

                    <li>
                        <a
                            href="#"
                            className="hover:text-blue-400 transition"
                        >
                            Industries
                        </a>
                    </li>

                    <li>
                        <a
                            href="#"
                            className="hover:text-blue-400 transition"
                        >
                            About
                        </a>
                    </li>

                    <li>
                        <a
                            href="#"
                            className="hover:text-blue-400 transition"
                        >
                            Contact
                        </a>
                    </li>

                </ul>

                <div className="hidden lg:flex">

                    <button className="px-7 py-3 rounded-full bg-blue-600 hover:bg-blue-500 transition">

                        Book Demo

                    </button>

                </div>

                <Menu className="lg:hidden" />

            </nav>

        </header>

    );
}